
#include <stdio.h>

#define MINIMO 1L
#define MAXIMO 1000000L


/* Cuenta los primos entre min y max */
long cuenta_primos(long min, long max);

/* Cuenta y encuentra los primos entre min y max y los devuelve en un vector */
long encuentra_primos(long min, long max, long vector[]);

/* Devuelve TRUE si n es primo */
int esprimo(long n);


