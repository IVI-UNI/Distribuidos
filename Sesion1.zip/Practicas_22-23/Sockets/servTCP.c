
/* 
   Luis C. Aparicio

        Sistemas Operativos
        �rea de Arquitectura y Tecnolog�a de computadores

   Programa servidor de suma utilizando sockets stream (TCP) 
 
   servTCP.c
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>

int main()
{
  struct sockaddr_in server_addr, client_addr;

  int sd, sc, salir;
  int size, res;
  int num[2];

  sd = socket(AF_INET, SOCK_STREAM, 0);

  /* Asigna la direcci�n al socket */
  bzero((char *)&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = INADDR_ANY;
  server_addr.sin_port = htons(5500);

  bind(sd, &server_addr, sizeof(server_addr));

  listen(sd, 5);

  size = sizeof(client_addr);
  salir = 0;

  while (salir == 0)
  {
    printf("Esperando conexi�n en el puerto: 5500\n"); fflush(stdout);
    sc = accept(sd, (struct sockaddr *)&client_addr, &size);
    if(sc < 0) salir = 1;
    else
    {
      /* recibe la petici�n, dos n�mero enteros */
      //read(sc, (char*) num, 2*sizeof(int));
      read(sc, &num, 2*sizeof(int));
      res = num[0] + num[1];

      printf("\nServicio: %d + %d = %d \n", num[0], num[1], res); fflush(stdout);

      /* env�a el resultado y cierra la conexi�n */
      //write(sc, (char*)&res, sizeof(int));
      write(sc, &res, sizeof(int));
      close (sc);
    }
  }

  printf("\n Error en accept \n"); fflush(stdout);
  close(sd);

  exit(0);
}
