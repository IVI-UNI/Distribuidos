
/* 
   Luis C. Aparicio

        Sistemas Operativos
        EUPT: �rea de Arquitectura y Tecnolog�a de computadores

   Programa servidor de suma utilizando sockets datagram (UDP) 
 
   servUDP.c
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>

int main()
{
  struct sockaddr_in server_addr, client_addr;

  int sd;
  int size, res;
  int num[2];

  sd = socket(AF_INET, SOCK_DGRAM, 0);

  /* Asigna la direcci�n al socket */
  bzero((char *)&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = INADDR_ANY;
  server_addr.sin_port = htons(4400);

  bind(sd, (struct sockaddr *)&server_addr, sizeof(server_addr));

  size = sizeof(client_addr);

  while (1)
  {
    printf("\nEsperando conexi�n en el puerto: 4400"); fflush(stdout);

    //recvfrom (sd, (char*) num, 2 * sizeof(int), 0, (struct sockaddr *)&client_addr, &size);
    recvfrom (sd, num, 2 * sizeof(int), 0, (struct sockaddr *)&client_addr, &size);
  
    res = num[0] + num[1];
    printf("\nServicio: %d + %d = %d \n", num[0], num[1], res); fflush(stdout);

    /* Env�a la petici�n al cliente. 
       La estructura client_addr contiene la direcci�n del socket del cliente */
     
    //sendto(sd, (char*)&res, sizeof(int), 0, (struct sockaddr *)&client_addr, size);  
    sendto(sd, &res, sizeof(int), 0, (struct sockaddr *)&client_addr, size);      
  }

}
