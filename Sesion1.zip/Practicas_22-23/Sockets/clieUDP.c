
/* 
   Luis C. Aparicio

        Sistemas Operativos
        EUPT: �rea de Arquitectura y Tecnolog�a de computadores

   Programa cliente para la suma utilizando sockets datagram (UDP) 
 
   clieUDP.c
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
  struct sockaddr_in server_addr, client_addr;
  struct hostent *hp;
  
  char *namehost; 

  int sd, puerto, res;
  int num[2];

  /* Tratamiento de par�metros */
  namehost = argv[1];
  puerto = atoi(argv[2]);
  num[0] = atoi(argv[3]);
  num[1] = atoi(argv[4]);

  sd = socket(AF_INET, SOCK_DGRAM, 0);

  /* Se optine y se rellena la direcci�n del servidor */
  bzero((char *)&server_addr, sizeof(server_addr));

  /* hp = gethostbyname("esquinazo.unizar.es"); */
  hp = gethostbyname(namehost);

  if (hp == NULL)
  {
    printf("\n Error en la llamada gethostbyname");
    exit(0);
  }
  
  bcopy (hp->h_addr, (char *)&(server_addr.sin_addr), hp->h_length);
  server_addr.sin_family = AF_INET;

  /*server_addr.sin_port = htons(4400); */
  server_addr.sin_port = htons(puerto); 

  /* Se rellena la direcci�n del cliente, cuando se utiliza el n�mero de puerto 0,
     el sistema se encarga de asignarle uno */
  bzero((char *) &client_addr, sizeof(client_addr));

  client_addr.sin_family = AF_INET;
  client_addr.sin_addr.s_addr = INADDR_ANY;
  client_addr.sin_port = htons(0); /* puerto asignado por el sistema */

  bind(sd, (struct sockaddr *)&client_addr, sizeof(client_addr));
  
  //sendto(sd, (char *)num, 2 * sizeof(int), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
  sendto(sd, num, 2 * sizeof(int), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));

  //recvfrom(sd, (char *)&res, sizeof(int), 0, NULL, NULL);
  recvfrom(sd, &res, sizeof(int), 0, NULL, NULL);

  printf("\n El resultado es %d \n", res);

  close(sd);
  
  exit(0);
}
