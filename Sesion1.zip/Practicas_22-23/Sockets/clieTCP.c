
/* 
   Luis C. Aparicio

        Sistemas Operativos
        �rea de Arquitectura y Tecnolog�a de computadores

   Programa cliente para la suma utilizando sockets stream (TCP) 
 
   clieTCP.c
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
  struct sockaddr_in server_addr;
  struct hostent *hp;
  
  char *namehost; 

  int sd, puerto, res;
  int num[2];

  /* Tratamiento de par�metros */
  namehost = argv[1];
  puerto = atoi(argv[2]);
  num[0] = atoi(argv[3]);
  num[1] = atoi(argv[4]);

  sd = socket(AF_INET, SOCK_STREAM, 0);

  /* Se obtine y se rellena la direcci�n del servidor */
  bzero((char *)&server_addr, sizeof(server_addr));

  /* hp = gethostbyname("esquinazo.unizar.es"); */
  hp = gethostbyname(namehost);

  if (hp == NULL)
  {
    printf("\n Error en la llamada gethostbyname");
    exit(0);
  }
  
  bcopy (hp->h_addr, (char *)&(server_addr.sin_addr), hp->h_length);
  server_addr.sin_family = AF_INET;

  /*server_addr.sin_port = htons(4200); */
  server_addr.sin_port = htons(puerto); 

  /* Se establece la conexi�n */  
  if (connect(sd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0)
  {
    perror("\n Error en la llamada connect");
    exit(0);
  }   
       
    /* env�a la petici�n */
  //write(sd, (char *) num, 2 *sizeof(int));
  write(sd, &num, 2 *sizeof(int));

    /* recibe la respuesta */
  //read(sd, (char *)&res, sizeof(int));
  read(sd, &res, sizeof(int));

  printf("\n El resultado es %d \n", res);
  close(sd);
  
  exit(0);
}
