
#include "funcpri.h"


long cuenta_primos(long min, long max)
{
  long i, contador;

  contador = 0;
  
  for (i = min; i <= max; i++)
    if (esprimo(i)) contador = contador + 1;

  return (contador);
}

long encuentra_primos(long min, long max, long vector[])
{
  long i, contador;

  contador = 0;

  for (i = min; i <= max; i++)
    if (esprimo(i)) vector[contador++] = i;

  return (contador);
}

int esprimo(long n)
{
  long i;

  for (i = 2; i*i <= n; i++)
    if ((n % i) == 0) return (0);

  return (1);
}

