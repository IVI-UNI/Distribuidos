/* 
   Luis C. Aparicio

        Sistemas Operativos
        �rea de Arquitectura y Tecnolog�a de computadores

   Programa cliente para la suma y resta de dos enteros utilizando RPC 
 
   clientRPC.c
*/


#include "calcular.h"

int main(int argc, char *argv[])
{
  int num1, num2;
  char *host;
  CLIENT *sv;
  int *ressum, *resres;

  host = argv[1];
  num1 = atoi(argv[2]);
  num2 = atoi(argv[3]);

  sv = clnt_create(host, CALCULAR, UNO, "tcp");

  if (sv == NULL)
  {
    clnt_pcreateerror(host);
    exit(0);
  }

  ressum = sumar_1(num1, num2, sv);

  if (ressum == NULL)
  {
    clnt_perror(sv, "error en suma RPC");
    exit(0);
  }

  printf ("La suma %d + %d = %d \n", num1, num2, *ressum);

  resres = restar_1(num1, num2, sv);

  if (resres == NULL)
  {
    clnt_perror(sv, "error en resta RPC");
    exit(0);
  }

  printf ("La resta %d - %d = %d \n", num1, num2, *resres);

  clnt_destroy(sv);

  exit(0);
}
