/* 
   Luis C. Aparicio

        Sistemas Operativos
        �rea de Arquitectura y Tecnolog�a de computadores

   Funciones RPC del servidor para la suma y resta de dos enteros
 
   clientRPC.c
*/

#include "calcular.h"

int *sumar_1_svc(int a, int b, struct svc_req *rqstp)
{
  static int r;
  r = a + b;
  return(&r);
}

int *restar_1_svc(int a, int b, struct svc_req *reqstp)
{
  static int r;
  r = a - b;
  return(&r);
}
