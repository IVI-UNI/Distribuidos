#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>


#define ROWS 10000
#define COLUMS 10000

int matA[ROWS][COLUMS];

int main(int argc, char *argv[])
{
  int dim, fd, entero, lectura;
  int indiceF, indiceC;
  
  // Dimensi�n Matriz
  dim = atoi(argv[1]);

  // Lectura y Carga de la Matriz: matA
  fd = open(argv[2], O_RDONLY);

  indiceF = 0;
  indiceC = 0;

  do
  {
    lectura = read(fd, &entero, 4);
    matA[indiceF][indiceC] = entero;
    indiceC++;
    if(indiceC == dim)
    {
      indiceF++;
      indiceC = 0;
    }
  } while(lectura > 0);
  /* */

  // Muestra por Pantalla la Matriz: matA
  for (indiceF = 0; indiceF < dim; indiceF++)
  {
    printf("\n");
    for(indiceC = 0; indiceC < dim; indiceC++)
      printf("matA[%d,%d] = %d \t", indiceF, indiceC, matA[indiceF][indiceC]);
  }
  printf("\n\n");

  return(0);
}
