#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int dim, fd, k, entero;

  // Dimensi��n Matriz
  dim = atoi(argv[1]);

  // Generar Matriz y guardarla en Fichero
  fd = creat(argv[2], 0600);

  srand(time(NULL));
  for (k = 0; k < dim*dim; k++)
  {
    entero = rand() % 9;
    write (fd, &entero, 4);
    // fprintf(stderr, "%d", entero);

  }

  return(0);
}
