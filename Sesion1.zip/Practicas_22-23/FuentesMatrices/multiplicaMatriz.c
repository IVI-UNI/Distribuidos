#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>


#define ROWS 10000
#define COLUMS 10000

int matA[ROWS][COLUMS];
int matB[ROWS][COLUMS];
int matC[ROWS][COLUMS];

int main(int argc, char *argv[])
{
  int dim, fdA, fdB, entero, lectura;
  int k, indiceF, indiceC;

  // Dimensi�n Matrices
  dim = atoi(argv[1]);

  // Lectura y Carga de la MatrizA: matA
  fdA = open(argv[2], O_RDONLY);

  indiceF = 0;
  indiceC = 0;

  do
  {
    lectura = read(fdA, &entero, 4);
    matA[indiceF][indiceC] = entero;
    indiceC++;
    if(indiceC == dim)
    {
      indiceF++;
      indiceC = 0;
    }
  } while(lectura > 0);
  /* */


  // Lectura y Carga de la MatrizB: matB
  fdB = open(argv[3], O_RDONLY);

  indiceF = 0;
  indiceC = 0;

  do
  {
    lectura = read(fdB, &entero, 4);
    matB[indiceF][indiceC] = entero;
    indiceC++;
    if(indiceC == dim)
    {
      indiceF++;
      indiceC = 0;
    }
  } while(lectura > 0);
  /* */


  //Multiplicaci�n de Matrices: matA x matB

  for (indiceF = 0; indiceF < dim; indiceF++)
    for (indiceC = 0; indiceC < dim; indiceC++)
    {
      matC[indiceF][indiceC] = 0;
      for (k = 0; k < dim; k++)
        matC[indiceF][indiceC] += matA[indiceF][k] * matB[k][indiceC];
    }
  /* */

  // Mostrar por Pantalla la MatrizC: matC (matriz Producto)
  for (indiceF = 0; indiceF < dim; indiceF++)
  {
    printf("\n");
    for(indiceC = 0; indiceC < dim; indiceC++)
      printf("matC[%d,%d] = %d \t", indiceF, indiceC, matC[indiceF][indiceC]);
  }
  printf("\n\n");

  return(0);
}
