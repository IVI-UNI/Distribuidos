/**
@author Cesar Vasquez Ibaceta
@version 2.0 16-11-05
*/

package src.server;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.HashMap;
import java.lang.Integer;
import java.lang.String;

import src.calculo.*;

/**
Este es el servidor que se encarga de realizar los calculos
en lugar del cliente remoto.
*/
public class MotorCalculo extends UnicastRemoteObject implements Calculo
{
    private static final long serialVersionUID = 123456L;
    private static HashMap<Integer,Integer> lista;

   /**
   Unico Constructor de la clase.
   @throws RemoteException todos las clases que heredan a UnicastRemoteObject 
   o a Remote, deben atrapar o lanzar esta excepcion. 
   */
   public MotorCalculo() throws RemoteException
   {
      super();
   }


   /**
   Realiza los calculos de la siguiente manera.<BR>
   1.- Revisa si el calculo fue previamente realizado y gusrdado<BR>
   2.- Si no, ejecuta el metodo "ejecutar()" de la clase remota, por
   medio de la interface Proceso.
   @param t Objeto de alguna clase que implemente a "Proceso", para
   realizar los calculos opsteriores.
   @return Retorna el resultado de la sumatoria.
   */
   public int ejecutarProceso(Proceso t)
   {
      System.out.println("\nMotorCalculo: me llamaron a ejecutar el proceso ... ");

      int numero = t.getNumber();

      if(lista.containsKey(new Integer(numero) ))
      {
         System.out.println("MotorCalculo: valor precalculado");
         System.out.println("MotorCalculo: numero  = " + numero);
         System.out.println("MotorCalculo:   suma  = " + lista.get(new Integer(numero) ));
         System.out.println("*********************************************");

         return Integer.parseInt(lista.get(numero).toString());
      }

      int suma = t.ejecutar();

      System.out.println("MotorCalculo: numero  = " + numero);
      System.out.println("MotorCalculo:   suma  = " + suma);
      System.out.println("*********************************************");

      lista.put(new Integer(numero), new Integer(suma) );
      return suma;
   }


   /**
   Clase principal, para que el programa servidor pueda
   ejecutarse.
   @param args Estos son los parametros de entrada al momento de ejecutar
   el servidor. Refierase al archivo leeme.txt para mayor informacion.<BR> 
   USO: MotorCalculo [THIS_HOST] [PUERTO].
   */
   public static void main(String[] args)
   {
      if (args.length != 2)
      {
         System.out.println("EjemploSumatoria: Sin argumentos");
         System.out.println("EjemploSumatoria: USO -> MotorCalculo [THIS_HOST] [PUERTO]");
         return;
      }

      if (System.getSecurityManager() == null)
      {
         System.out.println("MotorCalculo: Creando Security manager ... ");
         System.setSecurityManager(new RMISecurityManager());
      }

      String name = "//"+ args[0]+""+args[1]+"/MotorCalculo";
      lista = new HashMap<Integer, Integer>();
      try
      {
         String nombre = "//"+args[0]+":"+args[1]+ "/MotorCalculo";
         Calculo motor = new MotorCalculo();
         System.out.println("MotorCalculo: Motor de calculo registrandose ... ");
         
         Naming.rebind(nombre, motor);
         System.out.println("MotorCalculo: Motor de calculo ligado a " + args[0] + ":" + args[1] );
      }
      catch (Exception e)
      {
         System.err.println("MotorCalculo: Excepcion en motor de calculo: " +
            e.getMessage() + "\n");
         e.printStackTrace();
      }
   }
}


