/**
@author Cesar Vasquez Ibaceta
@version 2.0 16-11-05
*/
package src.calculo;

import java.io.Serializable;

/**
Interface creada para la comunicacion entre el
servidor y el cliente. Se encarga de realizar al
calculo de la sumatoria.
*/
public interface Proceso extends Serializable
{
   /**
   Ejecuta el calculo de la sumatoria
   @return Retorna el resultado de la sumatoria
   */
   int ejecutar();

   /**
   Metodo para acceder al numero que se desea procesar
   @return Retorna el numero al cual hay que aplicar
   el calculo.
   */
   int getNumber();
}
