/**
@author Cesar Vasquez Ibaceta
@version 2.0 16-11-05
*/
package src.calculo;

import java.rmi.Remote;
import java.rmi.RemoteException;

import src.calculo.Proceso;

/**
Interface necesaria para el funcionamiento de el
programa para RMI. Utilizada para la comunicacion
entre el servidor y el cleinte.
*/
public interface Calculo extends Remote
{
   /**
   Metodo encargado de "Ejecutar" un Objeto que implemente
   a Proceso, para realizar el calculo.
   @param t "Proceso" que realizar� la sumatoria
   @return retorna un entero, que es el resulatdo
   del calculo de la sumatoria.
   */
   int ejecutarProceso(Proceso t) throws RemoteException;
}
