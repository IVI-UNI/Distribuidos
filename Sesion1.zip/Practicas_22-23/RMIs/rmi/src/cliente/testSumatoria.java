/**
@author Cesar Vasquez Ibaceta
@version 2.0 16-11-05
*/
package src.cliente;

import java.rmi.*;
import java.math.*;

import src.calculo.*;

/**
Clase dedicada a probar el programa calculoSumatoria para
el proyecto de RMI, de Programacion de Sistemas.
*/
public class testSumatoria
{
   /**
   este constructor no hace nada.
   */
   public testSumatoria()
   {
   
   }
   
   /**
   Este es el metodo principal para comenzar a correr
   el programa de prueba. Los parametros son:<BR>
   <B>testSumatoria [HOST] [NUMERO]</B><BR>
   En donde [HOST] es la ubicacion del servidor, y [NUMERO] es el
   numero al que hay que calcular la sumatoria.
   */
   public static void main(String args[])
   {
      System.out.println("EjemploSumatoria: comienzo de programa");
      if (args.length != 3)
      {
         System.out.println("EjemploSumatoria: Sin argumentos");
         System.out.println("EjemploSumatoria: USO -> testSumatoria [HOST] [PORT] [NUMBER]");
         return;
      }

      
      System.setProperty("java.security.policy","/home/alm2000/cvasquez/elo330/rmi/.java.policy");
      //Se registra el RMISecurityManager localmente
      if (System.getSecurityManager() == null)
      {
         System.setSecurityManager(new RMISecurityManager());
      }


      try
      {
         String nombre = "rmi://" + args[0] + ":"+args[1]+"/MotorCalculo";
         System.out.println("EjemploSumatoria: consultando registro " + nombre + " ...");
         Calculo comp = (Calculo) Naming.lookup(nombre);
         System.out.println("EjemploSumatoria: stub obtenido, se ejecutara tarea");

         Proceso p = (Proceso) new calculoSumatoria(Integer.parseInt(args[2]));
         int suma = (comp.ejecutarProceso(p));
         System.out.println("EjemploSumatoria: LA SUMATORIA ES:    " + suma);
      }
      catch (Exception e)
      {
         System.err.println("EjemploSumatoria: Excepcion EjemploSumatoria => " +
            e.getMessage());
         e.printStackTrace();
      }
   }
}
