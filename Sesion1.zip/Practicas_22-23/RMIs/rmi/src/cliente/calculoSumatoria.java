/**
@author Cesar Vasquez Ibaceta
@version 2.0 16-11-05
*/
package src.cliente;

import src.calculo.Proceso;

/**
Esta clase realiza la sumatoria desde 0 hasta un determinado
numero pasado como parametro.
*/
public class calculoSumatoria implements Proceso
{
   private static final long serialVersionUID = 123456L;
   // entero al cual se le aplicara la sumatoria
   private int numero;

   /**
   Contruir una tarea para el calculo de la
   sumatoria de todos los enteros desde cero
   hasta "numero"
   @param numero numero sobre el cual hay que realizar el calculo.
   */
   public calculoSumatoria(int numero)
   {
      this.numero = numero;
   }


   /**
   Calcular la sumatoria.
   @return este metodo retorna el resultado de la sumatoria.
   */
   public int ejecutar()
   {
      return calcularSumatoria(numero);
   }


   /**
   Este metodo se utiliza para acceder al numero al que se le
   desea hacer la sumatoria.
   @return Retorna el entero al cual hay que realizar la sumatoria
   */
   public int getNumber()
   {
      return numero;
   }


   /**
   Calcula la sumatoria de los enteros desde cero hasta "n", utilizando
   para ello una formula simple.
   @param n Entero al que hay que aplicar la formula
   @return Retorna el resultado de la sumatoria.
   */
   public static int calcularSumatoria(int n)
   {
      System.out.println("....calcular sumatoria desde 1 hasta " + n + "...");
      int suma = 0;

      if(n%2 != 0)
         suma = ((n + 1) * ((n - 1) / 2) + ((n + 1) / 2));
      else
         suma = ((n + 1) * (n / 2));

      return suma;
   }
}

